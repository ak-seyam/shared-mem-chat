void ERRCHECKER_shared_memory_getting(int id);
void ERRCHECKER_shared_memory_atteching(char *id);
